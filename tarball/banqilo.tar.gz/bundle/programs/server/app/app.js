var require = meteorInstall({"imports":{"api":{"elos.js":["meteor/mongo",function(require,exports){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// imports/api/elos.js                                               //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
exports.__esModule = true;                                           //
exports.Elos = undefined;                                            //
                                                                     //
var _mongo = require('meteor/mongo');                                // 1
                                                                     //
var Elos = exports.Elos = new _mongo.Mongo.Collection('elos');       // 3
///////////////////////////////////////////////////////////////////////

}]}},"server":{"main.js":["meteor/meteor","../imports/api/elos.js",function(require){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// server/main.js                                                    //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
var _meteor = require('meteor/meteor');                              // 1
                                                                     //
require('../imports/api/elos.js');                                   // 2
                                                                     //
_meteor.Meteor.startup(function () {                                 // 4
  // code to run on server at startup                                //
});                                                                  //
///////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json",".jsx"]});
require("./server/main.js");
//# sourceMappingURL=app.js.map
